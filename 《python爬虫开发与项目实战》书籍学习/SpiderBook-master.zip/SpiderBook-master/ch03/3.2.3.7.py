#coding:utf-8
'''
Timeouts超时设置

requests.get('http://github.com', timeout=2)


'''
